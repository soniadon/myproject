<?php

namespace Drupal\tfm_client\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Client entities.
 *
 * @ingroup tfm_client
 */
class ClientDeleteForm extends ContentEntityDeleteForm {


}
