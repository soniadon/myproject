<?php

namespace Drupal\tfm_assessment\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Assessment entities.
 *
 * @ingroup tfm_assessment
 */
class AssessmentDeleteForm extends ContentEntityDeleteForm {


}
