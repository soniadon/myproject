<?php

namespace Drupal\tfm_project\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Project entities.
 *
 * @ingroup tfm_project
 */
class ProjectDeleteForm extends ContentEntityDeleteForm {


}
