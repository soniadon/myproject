<?php

namespace Drupal\tfm_tagging\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Tagging entities.
 *
 * @ingroup tfm_tagging
 */
class TaggingDeleteForm extends ContentEntityDeleteForm {


}
