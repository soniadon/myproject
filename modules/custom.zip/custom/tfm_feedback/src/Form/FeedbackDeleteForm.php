<?php

namespace Drupal\tfm_feedback\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Feedback entities.
 *
 * @ingroup tfm_feedback
 */
class FeedbackDeleteForm extends ContentEntityDeleteForm {


}
