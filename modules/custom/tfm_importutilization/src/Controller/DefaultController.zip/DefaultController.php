<?php

namespace Drupal\tfm_importutilization\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\user\Entity\User;
use Drupal\Core\Database\Driver\mysql\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;



class DefaultController extends ControllerBase {

	protected $db, $account;
/**
 * 
 * @param Connection $database
 * @param AccountInterface $AI_Obj
 */
	public function __construct(Connection $database, AccountInterface $AI_Obj){
		$this->db = $database;
		$this->account = $AI_Obj;
	}
/**
 * 
 * @param ContainerInterface $container
 * @return \static
 */
 public static function create(ContainerInterface $container){
   	 //load the service created  to construct this class
		$database = $container->get('database');
		$currentUserIFC = $container->get('current_user');
	 
	 return new static ( $database, $currentUserIFC );

 }

 /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function index() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Im Default function in Default controller. Im done my job')
    ];
  }
	
	/**
	 *
	 */
	public function showcontent(){
	 
	  $username = $this->account->getUsername(); 
    $email_Id = $this->account->getEmail(); 
    $Roles = $this->account->getRoles(); 
		///print_r($Roles);
		$roles_str = '';
		$i=1;
		foreach ($Roles as $eachrole){
			$roles_str .= '  '.$i.')' . $eachrole;
			$i++;
			
		}
	 
   //db_select is deprecated
   $select = $this->db->select('node', 'n');
   $select->fields('n');
  // $select->condition('type', "page", "=");
   $entries = $select->execute()->fetchAll(\PDO::FETCH_ASSOC);
   $page_count = count($entries);
   $myNumber =  '9880429900';
   $cow_service = \Drupal::service('cow.animal');
   $mycow = $cow_service->howDoYouLookLike();
    $build = [
       // Your theme hook name.
     '#theme' => 'corona_theme_hook',		 
     // variables to print. 
     '#name' => $username,
     '#email_Id' => $email_Id,
     '#cow' => $mycow,
     '#dbcontent' => $entries,
   ];
   return $build;

 }

 /**
  * 
  * @return string Returns a render-able array for a test page.
  */
  public function waffy() {
		
    $myText = 'Prabhakar';
    $myNumber = 1225;
    $myArray = [1, 2, 3, 4, 5, 6, 7, 8, 9,['Parimala', 'Vimala', 'Sahasra']];
    $build = [
        // Your theme hook name.
      '#theme' => 'dettol_theme_hook',
      // Your variables.
      '#name' => $myText,
      '#roll' => $myNumber,
      '#myArray' => $myArray,
    ];
    return $build;
  }
 /**
  * 
  * @param type $name
  * @return type
  */
  public function school($name){
    $student_det = '';
    $build = [
          // Your theme hook name.
      '#theme' => 'school_theme_hook',
      '#school_name'=> $name,
      '#student_det' => $student_det,
    ];
    return $build;

  }
  /*
  */
  function taxonomy_term_load_multiple_by_name($name, $vocabulary = NULL) {
    $values = array(
      'name' => trim($name),
    );
    if (isset($vocabulary)) {
      $vocabularies = taxonomy_vocabulary_get_names();
      if (isset($vocabularies[$vocabulary])) {
        $values['vid'] = $vocabulary;
      }
      else {
  
        // Return an empty array when filtering by a non-existing vocabulary.
        return array();
      }
    }
    return entity_load_multiple_by_properties('service_line', $values);
  }
  /*
  */
  public static function importutilization($row, &$context){
   
   
   if ($row['Emp_Id']!= "" &&$row['Emp_Username']!="" ){
    
    $c_account =  user_load_by_name($row['Emp_Username']);
    
    if ( !$c_account ) {
      $c_account = \Drupal\user\Entity\User::create();
      //Mandatory settings
      $c_account->setPassword('test@123');
      $c_account->enforceIsNew();
      $c_account->setEmail($row['Email_ID']);
      $c_account->setUsername($row['Emp_Username']);

      //Optional settings
      $c_account->activate();
      $c_account->set("status",1);     
    }
    
    $c_account->set("field_global_employee_id",$row['Global_Employee_Id']);
    $c_account->set("field_emp_id", $row['Emp_Id']); 
    $c_account->set("field_emp_name", $row['Emp_Name']);  
    $c_account->set("field_global_employee_id",$row['Global_Employee_Id']);
    $c_account->set("field_fresher",$row['Fresher']); 
    $c_account->set("field_hire_date",$row['Hire_Date']); 
    $c_account->set("field_lwd",$row['LWD']);
    $c_account->set("field_supervisor_name",$row['Supervisor_Name']); 
    $c_account->set("field_account",$row['Account']);
    $c_account->set("field_allocation_start_date",$row['Allocation_Start_Date']);
    $c_account->set("field_allocation_end_date",$row['Allocation_End_Date']);
    $c_account->set("field_resource_current_status",$row['Resource_Current_Status']);
    $c_account->set("field_hc",$row['HC']);
    $c_account->set("field_age",$row['Age']);
    $c_account->set("field_ou_code",$row['OU_Code']); 
    $c_account->set("field_employee_type",$row['Employee_Type']); 
    $c_account->set("field_captives_p_c",$row['Captives/P&C']); 
    $c_account->set("field_training_days_cal_days_",$row['Training_Days_(Cal_Days)']); 
    $c_account->set("field_shadow_day_cal_days_",$row['Shadow_Day_(Cal_Days)']);
    $c_account->set("field_billing_days_cal_days_",$row['Billing_Days_(Cal_Days)']);
    $c_account->set("field_account_availability",$row['Availability']);
    $c_account->set("field_non_deployable",$row['Non-Deployable']);
    $c_account->set("field_proposed_so_numbers",$row['Proposed_SO_Numbers']);
    $c_account->set("field_proposed_accounts",$row['Proposed_accounts']); 
    $c_account->set("field_proposed_dates",$row['Proposed_Dates']); 
    $c_account->set("field_last_cv_updated",$row['Last_CV_Updated']); 
    $c_account->set("field_sez_non_sez",$row['SEZ/Non-SEZ']); 
    $c_account->set("field_generic_skill",$row['Generic_Skill']); 
    $c_account->set("field_icx",$row['iCX']); 
    $term =  taxonomy_term_load_multiple_by_name($row['Service_Line']);
    $c_account->set("field_service_line",$term); 
    //Save user
    $res = $c_account->save();
    
    \Drupal::logger('tfm_importutilization')->notice($row['Emp_Id']);
     
     
     
   }
      
   
   
  }
  
   public static function  importutilizationFinishedCallback($success, $results, $operations) {
    // The 'success' parameter means no fatal PHP errors were detected. All
    // other error management should be handled using 'results'.
    if ($success) {
      $message = \Drupal::translation()->formatPlural(
        count($results),
        'One post processed.', '@count posts processed.'
      );
    }
    else {
      $message = t('Finished with an error.');
    }
   // drupal_set_message($message);
   \Drupal::messenger()->addMessage($message);
  }
  
  
}//end of class
